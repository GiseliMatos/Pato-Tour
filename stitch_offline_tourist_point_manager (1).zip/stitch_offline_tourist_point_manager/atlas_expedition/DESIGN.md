---
name: Atlas Expedition
colors:
  surface: '#f3faff'
  surface-dim: '#c7dde9'
  surface-bright: '#f3faff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#e6f6ff'
  surface-container: '#dbf1fe'
  surface-container-high: '#d5ecf8'
  surface-container-highest: '#cfe6f2'
  on-surface: '#071e27'
  on-surface-variant: '#424752'
  inverse-surface: '#1e333c'
  inverse-on-surface: '#dff4ff'
  outline: '#727783'
  outline-variant: '#c2c6d4'
  surface-tint: '#005db7'
  primary: '#004d99'
  on-primary: '#ffffff'
  primary-container: '#1565c0'
  on-primary-container: '#dae5ff'
  inverse-primary: '#a9c7ff'
  secondary: '#1b6d24'
  on-secondary: '#ffffff'
  secondary-container: '#a0f399'
  on-secondary-container: '#217128'
  tertiary: '#7d3c00'
  on-tertiary: '#ffffff'
  tertiary-container: '#a15000'
  on-tertiary-container: '#ffdfcc'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c7ff'
  on-primary-fixed: '#001b3d'
  on-primary-fixed-variant: '#00468c'
  secondary-fixed: '#a3f69c'
  secondary-fixed-dim: '#88d982'
  on-secondary-fixed: '#002204'
  on-secondary-fixed-variant: '#005312'
  tertiary-fixed: '#ffdcc6'
  tertiary-fixed-dim: '#ffb786'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#723600'
  background: '#f3faff'
  on-background: '#071e27'
  surface-variant: '#cfe6f2'
typography:
  headline-xl:
    fontFamily: Manrope
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Manrope
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
  code-coords:
    fontFamily: Inter
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 18px
    letterSpacing: 0.02em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-margin: 20px
  gutter: 16px
  card-padding: 16px
  touch-target-min: 48px
---

## Brand & Style

The design system is built for the "modern explorer"—someone who requires high-utility tools that feel both rugged and refined. The brand personality is rooted in reliability and adventure, bridging the gap between a professional mapping tool and an inspirational travel journal.

The aesthetic follows a **Corporate/Modern** foundation with **Tactile** influences. It utilizes generous whitespace, crisp iconography, and high-quality photography to ensure a professional feel. To differentiate from standard utility apps, it incorporates subtle depth through tonal layering and "squishy" interaction states on primary buttons to evoke the feeling of physical outdoor gear. The goal is to provide a UI that feels virtually indestructible yet incredibly lightweight.

## Colors

The palette is driven by "Trust and Terrain." **Deep Blue** (Primary) is used for core navigation, interactive states, and branding to establish systemic trust. **Adventure Green** (Secondary) is reserved for success states and "Safe" actions, like saving a point. **Vibrant Orange** (Tertiary) acts as the high-visibility accent for "Add" actions and critical alerts, ensuring they stand out against map backgrounds.

Surface colors utilize a "Paper and Slate" approach:
- **Surface:** Pure white (#FFFFFF) for primary content cards.
- **Background:** Ultra-light cool gray (#F8FAFC) to reduce glare during outdoor use.
- **Overlays:** Semi-transparent blurs are used for map-controls to maintain context of the underlying geography.

## Typography

This design system uses a dual-font strategy. **Manrope** is used for headlines to provide a modern, geometric character that feels premium and tech-forward. **Inter** is used for all functional text, body copy, and UI labels due to its exceptional legibility at small sizes and high-density screens.

Specific attention is paid to geocode data (Latitude/Longitude). These should be rendered in `code-coords` style, which uses Inter's medium weight to ensure numerical clarity. For mobile displays, headlines scale down to prevent awkward wrapping, while body sizes remain constant to ensure accessibility during movement.

## Layout & Spacing

The layout is optimized for single-handed mobile use. It follows an **8px base grid** for all spatial relationships. 

- **Margins:** A standard 20px horizontal margin is used for all page content to provide breathing room on mobile edges.
- **Safe Zones:** Top and bottom safe areas are strictly respected, with the FAB positioned 24px from the bottom-right corner.
- **Map View:** When the map is active, UI elements (Search, Zoom) should use a floating "island" layout with 12px spacing between elements.
- **Input Density:** Form fields should maintain a minimum height of 56px to ensure easy tapping in rugged environments.

## Elevation & Depth

Visual hierarchy is managed through **Tonal Layers** and **Ambient Shadows**. This design system avoids harsh blacks, instead using deep blue-tinted shadows for a more natural appearance.

- **Level 0 (Base):** Background and Map.
- **Level 1 (Submerged):** Search bars and inactive input fields (low-contrast 1px border).
- **Level 2 (Surface):** List cards and navigation bars (12px blur, 4% opacity shadow).
- **Level 3 (Elevated):** FABs and Active Dialogs (24px blur, 12% opacity shadow, slightly offset on Y-axis).

Interactions should feel tactile; when a card or button is pressed, its elevation should decrease (the shadow shrinks) to mimic physical displacement.

## Shapes

The design system employs a **Rounded (Level 2)** shape language. This provides a friendly, modern feel that balances the "seriousness" of the blue/green color palette.

- **Buttons & Inputs:** 0.5rem (8px) corner radius.
- **Cards & Modals:** 1rem (16px) corner radius.
- **FAB & Avatars:** Fully circular (Pill-shaped) to distinguish them as high-priority interactive elements.

Consistency in corner radii across inputs and buttons ensures the forms look unified and structured.

## Components

### Buttons & FAB
The **Floating Action Button (FAB)** is the primary driver for creating new points. It should be a 56x56px circle using the Tertiary color (#F57C00) with a white plus icon. Standard buttons use the Primary Blue, featuring a slight 2px bottom border (10% darker than the base color) to add tactile depth.

### Cards
Tourist point cards feature a fixed-aspect-ratio (16:9) thumbnail on the left or top. Metadata (Title, Coordinates, Rating) is stacked to the right or bottom. Cards should utilize a subtle 1px border (#E2E8F0) in addition to their elevation to ensure definition against map overlays.

### Form Inputs
Inputs use a "contained" style with a light gray fill (#F1F5F9) that transitions to a white background with a Primary Blue border on focus. Geocode inputs (Lat/Long) should include "prefix" icons (Compass/Pin) to provide visual context immediately.

### Map Controls
Zoom and location-centering buttons are grouped in vertical stacks. These use a "Glassmorphic" background (White with 80% opacity and 10px backdrop blur) to remain visible without totally obscuring the map.

### Toggles & Sliders
Used for filtering (e.g., "Show visited"). Toggles use the Secondary Green for the 'On' state to indicate an active, healthy status. Sliders for distance radius should feature a prominent "thumb" (24x24px) for easy manipulation.